Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                  <img src="<?php echo e(asset('img/logo_impocargo.png')); ?>" height="35px"/>
                </a>
            </div>
            
                    <!-- Call Search -->
                    
                    <!-- #END# Call Search -->
                    <!-- Notifications -->
                    
                    <!-- #END# Notifications -->
                    
                
        </div>
    </nav>
    <!-- #Top Bar
